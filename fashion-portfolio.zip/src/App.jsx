import React from "react";
import { Mail, Instagram, Linkedin } from "lucide-react";

const projects = [
  {
    title: "Spring/Summer 2024 Collection",
    description: "A modern take on vintage silhouettes with sustainable fabrics and hand-crafted embroidery.",
    tech: ["Silk", "Organic Cotton", "Handmade"],
  },
  {
    title: "Fashion Show - Paris 2023",
    description: "Showcased a runway collection blending urban minimalism with haute couture aesthetics.",
    tech: ["Runway", "Urban Minimalism", "Haute Couture"],
  },
];

export default function Portfolio() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-white to-rose-100 text-gray-800 p-8">
      <section className="text-center py-12">
        <h1 className="text-5xl font-extrabold tracking-tight">Amit Kothari</h1>
        <p className="text-xl mt-4 font-medium">Fashion Designer | Sustainable | Contemporary</p>
        <div className="flex justify-center gap-6 mt-6 text-pink-600">
          <a href="mailto:amit@example.com"><Mail size={24} /></a>
          <a href="https://instagram.com/amitkothari"><Instagram size={24} /></a>
          <a href="https://linkedin.com/in/amitkothari"><Linkedin size={24} /></a>
        </div>
      </section>

      <section className="max-w-4xl mx-auto py-8">
        <h2 className="text-3xl font-bold mb-4 border-b pb-2">About Me</h2>
        <p className="text-lg leading-relaxed">
          I'm a contemporary fashion designer with a passion for eco-conscious design, elegant silhouettes, and meaningful storytelling through fabric. My work blends modern minimalism with timeless craftsmanship.
        </p>
      </section>

      <section className="max-w-5xl mx-auto py-8">
        <h2 className="text-3xl font-bold mb-6 border-b pb-2">Collections</h2>
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((proj, idx) => (
            <div key={idx} className="border rounded-2xl p-6 shadow-lg bg-white hover:shadow-xl transition duration-300">
              <h3 className="text-2xl font-semibold mb-2">{proj.title}</h3>
              <p className="text-gray-600 mb-3">{proj.description}</p>
              <div className="flex flex-wrap gap-2">
                {proj.tech.map((t, i) => (
                  <span key={i} className="bg-rose-100 text-rose-800 rounded-full px-3 py-1 text-xs font-medium">{t}</span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-4xl mx-auto py-8">
        <h2 className="text-3xl font-bold mb-4 border-b pb-2">Expertise</h2>
        <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-lg">
          <li><strong>Design:</strong> Pattern Making, Draping, Textile Curation</li>
          <li><strong>Technology:</strong> Adobe Illustrator, CLO 3D, Photoshop</li>
          <li><strong>Focus:</strong> Sustainable Fashion, Couture, Runway</li>
        </ul>
      </section>

      <section className="text-center py-12">
        <h2 className="text-3xl font-bold mb-4">Let’s Collaborate</h2>
        <p className="text-lg mb-2">Reach out for custom designs, styling gigs, or fashion projects!</p>
        <a
          className="inline-block bg-rose-600 text-white px-6 py-3 rounded-full text-lg font-medium hover:bg-rose-700 transition"
          href="mailto:amit@example.com"
        >
          amit@example.com
        </a>
      </section>
    </div>
  );
}
